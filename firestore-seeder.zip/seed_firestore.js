// Seeder script for Firestore
const admin = require("firebase-admin");
const serviceAccount = require("./serviceAccount.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

async function seed() {
  const stones = [
    { name: "Ruby", type: "Precious", weight: "2 carats" },
    { name: "Emerald", type: "Precious", weight: "1.5 carats" },
    { name: "Amethyst", type: "Semi-precious", weight: "3 carats" }
  ];
  for (const stone of stones) {
    await db.collection("stones").add(stone);
  }
  console.log("✅ Firestore seeded with sample stones.");
}

seed().catch(console.error);
